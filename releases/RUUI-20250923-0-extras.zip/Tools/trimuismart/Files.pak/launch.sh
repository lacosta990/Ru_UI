#!/bin/sh

cd $(dirname "$0")

HOME="$SDCARD_PATH"
./DinguxCommander