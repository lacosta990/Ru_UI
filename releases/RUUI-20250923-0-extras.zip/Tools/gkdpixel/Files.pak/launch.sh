#!/bin/sh

cd $(dirname "$0")

HOME="$SDCARD_PATH"
/usr/bin/opkrun /media/data/apps/dinguxcmd_kai.opk
