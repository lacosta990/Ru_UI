#!/bin/sh

cd $(dirname "$0")
./minput.elf
