#/bin/bash

cd "$(dirname "$0")"

bash ./apply.sh > ./log.txt 2>&1