#!/bin/sh

cd $(dirname "$0")
./apply.sh > ./log.txt 2>&1