#!/bin/sh

cd "$(dirname "$0")"
./351Files